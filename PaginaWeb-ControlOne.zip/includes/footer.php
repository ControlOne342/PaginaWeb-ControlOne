    <!-- Footer -->
    <footer class="bg-primary text-white pt-16 pb-8 mt-auto">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
                
                <!-- Col 1: Marca -->
                <div class="space-y-4">
                    <a href="index.php" class="inline-block mb-2">
    					<img src="assets/img/Logo-CO.avif" alt="Control One" class="h-12 w-auto">
					</a>
                    <p class="text-gray-300 text-sm leading-relaxed">
                        Líderes en soluciones de seguridad logística. Protegemos tu carga con sellos de alta calidad y certificación ISO.
                    </p>
                    <div class="flex space-x-4 pt-2">
                        <!-- Facebook Icon -->
                        <a href="#" class="text-gray-300 hover:text-accent transition-colors">
                            <span class="sr-only">Facebook</span>
                            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        </a>
                        <!-- LinkedIn Icon -->
                        <a href="#" class="text-gray-300 hover:text-accent transition-colors">
                            <span class="sr-only">LinkedIn</span>
                            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                        </a>
                    </div>
                </div>

                <!-- Col 2: Soluciones -->
                <div>
                    <h4 class="text-lg font-semibold mb-6 text-accent">Soluciones</h4>
                    <ul class="space-y-3 text-sm">
                        <li><a href="productos.php#alta-seguridad" class="text-gray-300 hover:text-white transition-colors">Sellos de Alta Seguridad</a></li>
                        <li><a href="productos.php#plasticos" class="text-gray-300 hover:text-white transition-colors">Sellos de Plástico</a></li>
                        <li><a href="productos.php#metalicos" class="text-gray-300 hover:text-white transition-colors">Sellos Metálicos</a></li>
                        <li><a href="productos.php#cables" class="text-gray-300 hover:text-white transition-colors">Sellos de Cable</a></li>
                    </ul>
                </div>

                <!-- Col 3: Empresa -->
                <div>
                    <h4 class="text-lg font-semibold mb-6 text-accent">Empresa</h4>
                    <ul class="space-y-3 text-sm">
                        <li><a href="nosotros.php" class="text-gray-300 hover:text-white transition-colors">Nosotros</a></li>
                        <li><a href="contacto.php" class="text-gray-300 hover:text-white transition-colors">Contacto</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition-colors">Aviso de Privacidad</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition-colors">Términos y Condiciones</a></li>
                    </ul>
                </div>

                <!-- Col 4: Contacto -->
                <div>
                    <h4 class="text-lg font-semibold mb-6 text-accent">Contacto</h4>
                    <ul class="space-y-4 text-sm text-gray-300">
                        <li class="flex items-start">
                            <svg class="h-5 w-5 text-accent mr-3 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            <span>Av. Industrial 123, Parque Logístico, CP 54000, Edo. Méx.</span>
                        </li>
                        <li class="flex items-center">
                            <svg class="h-5 w-5 text-accent mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                            <span>+52 55 1234 5678</span>
                        </li>
                        <li class="flex items-center">
                            <svg class="h-5 w-5 text-accent mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <a href="mailto:contacto@controlone.com" class="hover:text-white transition-colors">contacto@controlone.com</a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Bottom Bar -->
            <div class="border-t border-gray-700 pt-8 text-center">
                <p class="text-gray-400 text-sm">
                    &copy; 2025 Control One. Todos los derechos reservados.
                </p>
            </div>
        </div>
    </footer>
</body>
</html>
